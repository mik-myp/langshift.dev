from task_app.app import main

if __name__ == "__main__":
    main()
